package com.keven.real;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.util.concurrent.CompletionStage;
import org.json.JSONObject;

public class SignalClient {
    public interface Listener { void onMessage(JSONObject o); void onStatus(String s); }

    private final Listener listener;
    private WebSocket ws;

    public SignalClient(Listener l) { listener = l; }

    public void connect(String url) {
        try {
            ws = HttpClient.newHttpClient()
                    .newWebSocketBuilder()
                    .buildAsync(URI.create(url), new WebSocket.Listener() {
                        private final StringBuilder buffer = new StringBuilder();

                        @Override
                        public void onOpen(WebSocket webSocket) {
                            listener.onStatus("CONNECTED");
                            webSocket.request(1);
                        }

                        @Override
                        public CompletionStage<?> onText(WebSocket webSocket, CharSequence data, boolean last) {
                            buffer.append(data);
                            if (last) {
                                try { listener.onMessage(new JSONObject(buffer.toString())); }
                                catch (Exception ignored) {}
                                buffer.setLength(0);
                            }
                            webSocket.request(1);
                            return null;
                        }

                        @Override
                        public void onError(WebSocket webSocket, Throwable error) {
                            listener.onStatus("ERROR: " + error.getMessage());
                        }

                        @Override
                        public CompletionStage<?> onClose(WebSocket webSocket, int statusCode, String reason) {
                            listener.onStatus("DISCONNECTED");
                            return null;
                        }
                    }).join();
        } catch (Exception e) {
            listener.onStatus("ERROR: " + e.getMessage());
        }
    }

    public void send(JSONObject o) {
        if (ws != null) ws.sendText(o.toString(), true);
    }
}
