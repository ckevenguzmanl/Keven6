package com.keven.real;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;

public class CallActivity extends Activity {
    public void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setGravity(Gravity.CENTER);r.setPadding(30,30,30,30);
        boolean video=getIntent().getBooleanExtra("video",true);
        TextView t=new TextView(this);t.setText(video?"📹 KEVEN — VIDEOLLAMADA":"📞 KEVEN — LLAMADA");t.setTextSize(26);t.setGravity(17);r.addView(t);
        TextView s=new TextView(this);s.setText("Preparando conexión WebRTC…");s.setTextSize(18);s.setGravity(17);r.addView(s);
        Button end=new Button(this);end.setText("COLGAR");r.addView(end);
        end.setOnClickListener(v->finish());
        setContentView(r);
    }
}
